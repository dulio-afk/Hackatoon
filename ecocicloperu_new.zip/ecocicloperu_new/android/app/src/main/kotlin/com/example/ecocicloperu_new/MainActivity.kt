package com.example.ecocicloperu_new

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
