import 'package:flutter/material.dart';

class EducacionViewModel extends ChangeNotifier {
  // Datos y métodos para gestionar el contenido educativo.
}
