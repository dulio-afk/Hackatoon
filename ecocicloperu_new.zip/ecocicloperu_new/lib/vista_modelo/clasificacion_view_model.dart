import 'package:flutter/material.dart';

class ClasificacionViewModel extends ChangeNotifier {
  // Datos y métodos para gestionar la clasificación de residuos.
}
