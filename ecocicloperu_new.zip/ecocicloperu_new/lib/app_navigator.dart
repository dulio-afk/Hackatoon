import 'package:flutter/material.dart';
import 'pantallas/pantalla_inicio.dart';
import 'pantallas/pantalla_login.dart';
import 'servicios/firebase_auth_service.dart';
import 'package:firebase_auth/firebase_auth.dart';

class AppNavigator extends StatelessWidget {
  const AppNavigator({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<User?>(
      future: FirebaseAuthService.getCurrentUser(),  // Llamamos a getCurrentUser
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        } else if (snapshot.hasData && snapshot.data != null) {
          return const PantallaInicio();  // Si hay un usuario autenticado, ir a la pantalla de inicio
        } else {
          return const PantallaLogin();  // Si no hay usuario, mostrar la pantalla de login
        }
      },
    );
  }
}


