import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'pantallas/pantalla_login.dart';
import 'pantallas/pantalla_registro.dart';
import 'pantallas/pantalla_inicio.dart';
import 'pantallas/pantalla_camara.dart';
import 'pantallas/pantalla_reporte.dart';
import 'pantallas/pantalla_educacion.dart';
import 'pantallas/pantalla_fotos.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(); // Inicializa Firebase
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Mi App',
      initialRoute: '/',
      onGenerateRoute: RouteGenerator.generateRoute,
    );
  }
}

class RouteGenerator {
  static Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case '/':
        return MaterialPageRoute(builder: (_) => const PantallaLogin());
      case '/registro':
        return MaterialPageRoute(builder: (_) => const PantallaRegistro());
      case '/inicio':
        return MaterialPageRoute(builder: (_) => const PantallaInicio());
      case '/camara':
        return MaterialPageRoute(builder: (_) => const PantallaCamara());
      case '/reporte':
        return MaterialPageRoute(builder: (_) => const PantallaReporte());
      case '/educacion':
        return MaterialPageRoute(builder: (_) => const PantallaEducacion());
      case '/fotos':
        return MaterialPageRoute(builder: (_) => const PantallaFotos());
      default:
        return MaterialPageRoute(
          builder: (_) => Scaffold(
            appBar: AppBar(title: const Text('Error')),
            body: const Center(child: Text('Ruta no encontrada')),
          ),
        );
    }
  }
}
