import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class FirebaseAuthService {
  // Función para obtener el usuario actual
  static Future<User?> getCurrentUser() async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      return user;
    } catch (e) {
      throw Exception('Error al obtener el usuario actual: $e');
    }
  }

  // Función de inicio de sesión
  static Future<User?> signIn(String email, String password) async {
    try {
      final UserCredential userCredential = await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
      final User? user = userCredential.user;
      if (user == null) {
        throw Exception('No se obtuvo un usuario válido');
      }
      return user;
    } catch (e) {
      throw Exception('Error de inicio de sesión: $e');
    }
  }

  // Función de registro con almacenamiento de datos adicionales
  static Future<User?> register(
      String email,
      String password,
      String name,
      String surname,
      String phone,
      String gender,
      String dob,
      ) async {
    try {
      final UserCredential userCredential = await FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );

      final User? user = userCredential.user;
      if (user != null) {
        // Guardar datos adicionales del usuario en Firestore
        await saveUserData(user.uid, name, surname, phone, gender, dob);
      }

      return user;
    } catch (e) {
      if (e is FirebaseAuthException) {
        throw Exception('Error de Firebase: ${e.message}');
      }
      throw Exception('Error al registrar el usuario: $e');
    }
  }

  // Función para guardar datos adicionales del usuario
  static Future<void> saveUserData(
      String userId,
      String name,
      String surname,
      String phone,
      String gender,
      String dob,
      ) async {
    try {
      await FirebaseFirestore.instance.collection('usuarios').doc(userId).set({
        'name': name,
        'surname': surname,
        'phone': phone,
        'gender': gender,
        'dob': dob,
      }, SetOptions(merge: true));  // Merge para evitar sobrescribir datos
    } catch (e) {
      throw Exception('Error al guardar los datos del usuario: $e');
    }
  }

  // Función para obtener los datos del usuario desde Firestore
  static Future<Map<String, dynamic>?> getUserData(String userId) async {
    try {
      final docSnapshot = await FirebaseFirestore.instance.collection('usuarios').doc(userId).get();
      if (docSnapshot.exists) {
        return docSnapshot.data();
      } else {
        return null;
      }
    } catch (e) {
      throw Exception('Error al obtener los datos del usuario: $e');
    }
  }

  // Función para cerrar sesión
  static Future<void> signOut() async {
    try {
      await FirebaseAuth.instance.signOut();
    } catch (e) {
      throw Exception('Error al cerrar sesión: $e');
    }
  }

  // Función para verificar si hay un usuario autenticado
  static bool isUserLoggedIn() {
    return FirebaseAuth.instance.currentUser != null;
  }

  // Función para recuperar la contraseña
  static Future<void> resetPassword(String email) async {
    try {
      await FirebaseAuth.instance.sendPasswordResetEmail(email: email);
    } catch (e) {
      throw Exception('Error al enviar el correo de recuperación: $e');
    }
  }
}
