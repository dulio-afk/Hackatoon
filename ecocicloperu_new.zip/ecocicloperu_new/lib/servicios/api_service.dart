import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  final String flaskBackendUrl = 'http://127.0.0.1:8080/predict'; // Cambia a la URL de tu backend Flask
  final String openAiApiKey = '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';

  // Método para enviar imagen al backend Flask
  Future<Map<String, dynamic>> classifyImage(String imagePath) async {
    try {
      final request = http.MultipartRequest('POST', Uri.parse(flaskBackendUrl));
      request.files.add(await http.MultipartFile.fromPath('file', imagePath));

      final response = await request.send();
      if (response.statusCode == 200) {
        final responseBody = await response.stream.bytesToString();
        return json.decode(responseBody);
      } else {
        throw Exception('Error en el backend Flask: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Error al conectar con el backend Flask: $e');
    }
  }

  // Método para mejorar la clasificación con OpenAI
  Future<String> improveClassification(String classification) async {
    try {
      final response = await http.post(
        Uri.parse('https://api.openai.com/v1/completions'),
        headers: {
          'Authorization': 'Bearer $openAiApiKey',
          'Content-Type': 'application/json',
        },
        body: json.encode({
          'model': 'text-davinci-003',
          'prompt': 'Mejora este resultado de clasificación: $classification',
          'max_tokens': 100,
        }),
      );

      if (response.statusCode == 200) {
        final responseBody = json.decode(response.body);
        return responseBody['choices'][0]['text'].trim();
      } else {
        throw Exception('Error en la API de OpenAI: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Error al conectar con OpenAI: $e');
    }
  }
}