import 'package:firebase_database/firebase_database.dart';

class FirebaseDatabaseService {
  final DatabaseReference _db = FirebaseDatabase.instance.ref(); // Actualización para la nueva versión

  // Método para agregar un nuevo elemento en la base de datos
  Future<void> addItem(String path, Map<String, dynamic> data) async {
    try {
      await _db.child(path).push().set(data);
      print("Elemento agregado con éxito.");
    } catch (e) {
      print('Error al agregar elemento: $e');
    }
  }

  // Método para obtener todos los elementos de una ruta específica
  Future<DataSnapshot> getItems(String path) async {
    try {
      // Usamos get() en lugar de once()
      DataSnapshot snapshot = await _db.child(path).get();
      return snapshot;
    } catch (e) {
      print('Error al obtener elementos: $e');
      rethrow;
    }
  }

  // Método para actualizar un elemento en la base de datos
  Future<void> updateItem(String path, Map<String, dynamic> data) async {
    try {
      await _db.child(path).update(data);
      print("Elemento actualizado con éxito.");
    } catch (e) {
      print('Error al actualizar elemento: $e');
    }
  }

  // Método para eliminar un elemento de la base de datos
  Future<void> deleteItem(String path) async {
    try {
      await _db.child(path).remove();
      print("Elemento eliminado con éxito.");
    } catch (e) {
      print('Error al eliminar elemento: $e');
    }
  }
}

