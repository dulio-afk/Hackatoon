import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:flutter/services.dart' show rootBundle;

class GoogleVisionService {
  final String _apiUrl = "https://vision.googleapis.com/v1/images:annotate";

  Future<String> classifyImage(File image) async {
    // Carga la clave del archivo JSON
    final String jsonKey = await rootBundle.loadString('assets/ecociclo-fbe95d9d95ce.json');
    final Map<String, dynamic> keyData = jsonDecode(jsonKey);
    final String apiKey = keyData['private_key_id'];

    // Convierte la imagen a base64
    final List<int> imageBytes = await image.readAsBytes();
    final String base64Image = base64Encode(imageBytes);

    // Configura la solicitud a Vision API
    final Map<String, dynamic> requestPayload = {
      "requests": [
        {
          "image": {"content": base64Image},
          "features": [{"type": "LABEL_DETECTION", "maxResults": 10}]
        }
      ]
    };

    final response = await http.post(
      Uri.parse('$_apiUrl?key=$apiKey'),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode(requestPayload),
    );

    if (response.statusCode == 200) {
      final responseData = jsonDecode(response.body);
      final annotations = responseData['responses'][0]['labelAnnotations'];
      return annotations.map((label) => label['description']).join(', ');
    } else {
      throw Exception('Error al clasificar la imagen: ${response.body}');
    }
  }
}