import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../servicios/firebase_auth_service.dart';
import 'pantalla_chatgpt.dart'; // Asegúrate de importar la pantalla de chat
import 'pantalla_fotos.dart';  // Importa la pantalla de fotos

class PantallaInicio extends StatelessWidget {
  const PantallaInicio({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final User? user = FirebaseAuth.instance.currentUser;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.green.shade600,
        title: const Text(
          'EcoCiclo Perú',
          style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
        ),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.exit_to_app),
            onPressed: () {
              _cerrarSesion(context);
            },
          ),
        ],
      ),
      body: Stack(
        children: [
          // Aquí va tu contenido principal de la pantalla
          FutureBuilder<DocumentSnapshot>(  // Aquí cargamos los datos del usuario
            future: FirebaseFirestore.instance.collection('usuarios').doc(user?.uid).get(),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              }

              if (snapshot.hasError) {
                return const Center(child: Text('Error al cargar los datos del usuario.'));
              }

              if (snapshot.hasData) {
                final userData = snapshot.data!;
                String userName = 'Usuario';
                try {
                  if (userData.exists && userData.data() != null) {
                    final Map<String, dynamic> data = userData.data() as Map<String, dynamic>;
                    if (data.containsKey('name')) {
                      userName = data['name'] ?? 'Usuario';
                    }
                  }
                } catch (e) {
                  print('Error al acceder al campo "name": $e');
                }

                return Stack(
                  children: [
                    CustomPaint(
                      size: Size(MediaQuery.of(context).size.width, MediaQuery.of(context).size.height),
                      painter: HojaRedondaPainter(),
                    ),
                    Container(
                      padding: const EdgeInsets.all(16.0),
                      color: Colors.white.withOpacity(0.8),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Text(
                            'EcoCiclo Perú',
                            style: TextStyle(
                              fontSize: 32,
                              fontWeight: FontWeight.bold,
                              color: Colors.orangeAccent,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            'Bienvenido, $userName',
                            style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w500,
                              color: Colors.black87,
                            ),
                          ),
                          const SizedBox(height: 20),
                          _buildOption(
                            context,
                            icon: FontAwesomeIcons.recycle,
                            title: 'Clasificar Residuos',
                            description: 'Aprende cómo clasificar adecuadamente tus residuos.',
                            color: Colors.green.shade600,
                            route: '/camara',
                          ),
                          const SizedBox(height: 20),
                          _buildOption(
                            context,
                            icon: FontAwesomeIcons.book,
                            title: 'Educación Ambiental',
                            description: 'Descubre consejos y recursos para cuidar el medio ambiente.',
                            color: Colors.blue.shade600,
                            route: '/educacion',
                          ),
                          const SizedBox(height: 20),
                          _buildOption(
                            context,
                            icon: FontAwesomeIcons.exclamationTriangle,
                            title: 'Reportar Acumulación',
                            description: 'Informa sobre zonas con acumulación de residuos.',
                            color: Colors.orange.shade700,
                            route: '/reporte',
                          ),
                          const SizedBox(height: 20),
                          // Opción para acceder a la pantalla de fotos clasificadas
                          _buildOption(
                            context,
                            icon: FontAwesomeIcons.image,
                            title: 'Fotos Clasificadas',
                            description: 'Mira las fotos de los residuos clasificados.',
                            color: Colors.purple.shade600,
                            route: '/fotos',  // Ruta hacia la pantalla de fotos
                          ),
                        ],
                      ),
                    ),
                  ],
                );
              }

              return const Center(child: Text('No se encontraron datos del usuario.'));
            },
          ),

          // Burbuja flotante para iniciar el chat con ChatGPT
          Positioned(
            bottom: 20,
            right: 20,
            child: FloatingActionButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const PantallaChatGPT()),
                );
              },
              backgroundColor: Colors.blue,
              child: Icon(FontAwesomeIcons.robot, size: 30),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildOption(BuildContext context, {
    required IconData icon,
    required String title,
    required String description,
    required Color color,
    required String route,
  }) {
    return InkWell(
      onTap: () {
        Navigator.pushNamed(context, route);
      },
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16.0),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.shade300,
              blurRadius: 8,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              margin: const EdgeInsets.all(16.0),
              padding: const EdgeInsets.all(16.0),
              decoration: BoxDecoration(
                color: color.withOpacity(0.2),
                borderRadius: BorderRadius.circular(16.0),
              ),
              child: Icon(
                icon,
                size: 40,
                color: color,
              ),
            ),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: color,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    description,
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.grey.shade600,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _cerrarSesion(BuildContext context) {
    FirebaseAuthService.signOut();
    Navigator.pushReplacementNamed(context, '/');  // Redirige a la pantalla de login
  }
}

class HojaRedondaPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    Paint paint = Paint()
      ..color = Colors.green.shade600
      ..style = PaintingStyle.fill;

    // Dibujo de la hoja redonda
    Path hoja = Path()
      ..moveTo(size.width * 0.5, size.height * 0.2)
      ..quadraticBezierTo(size.width * 0.3, size.height * 0.05, size.width * 0.1, size.height * 0.4)
      ..quadraticBezierTo(size.width * 0.05, size.height * 0.6, size.width * 0.4, size.height * 0.75)
      ..quadraticBezierTo(size.width * 0.7, size.height * 0.9, size.width * 0.9, size.height * 0.75)
      ..quadraticBezierTo(size.width * 0.95, size.height * 0.6, size.width * 0.8, size.height * 0.4)
      ..quadraticBezierTo(size.width * 0.7, size.height * 0.05, size.width * 0.5, size.height * 0.2)
      ..close();

    // Dibujo de las venas
    Paint veinPaint = Paint()
      ..color = Colors.green.shade800
      ..strokeWidth = 2;

    canvas.drawPath(hoja, paint); // Dibuja la hoja
    canvas.drawLine(Offset(size.width * 0.5, size.height * 0.2), Offset(size.width * 0.5, size.height * 0.75), veinPaint); // Vena central

    // Dibujar las venas laterales
    canvas.drawLine(Offset(size.width * 0.5, size.height * 0.5), Offset(size.width * 0.3, size.height * 0.6), veinPaint);
    canvas.drawLine(Offset(size.width * 0.5, size.height * 0.5), Offset(size.width * 0.7, size.height * 0.6), veinPaint);
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) {
    return false;
  }
}

