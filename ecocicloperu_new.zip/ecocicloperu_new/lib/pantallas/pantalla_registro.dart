import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../servicios/firebase_auth_service.dart';

class PantallaRegistro extends StatefulWidget {
  const PantallaRegistro({Key? key}) : super(key: key);

  @override
  State<PantallaRegistro> createState() => _PantallaRegistroState();
}

class _PantallaRegistroState extends State<PantallaRegistro> {
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _confirmPasswordController = TextEditingController();

  final _nameController = TextEditingController(); // Campo nombre
  final _surnameController = TextEditingController(); // Campo apellidos
  final _phoneController = TextEditingController(); // Campo teléfono
  final _dobController = TextEditingController(); // Campo fecha de nacimiento

  // Controlador para el género, con un valor inicial
  String? _selectedGender = 'Elegir Género';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Fondo con olas animadas
          Positioned.fill(
            child: CustomPaint(
              painter: WavePainter(),  // Olas más abajo
            ),
          ),
          // Contenido del registro
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: Center(
              child: SingleChildScrollView(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    // Título llamativo con nueva tipografía usando Google Fonts
                    Text(
                      'Regístrate en EcoCiclo Perú',
                      style: GoogleFonts.lora(
                        fontSize: 32,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,  // Color brillante para contraste
                        shadows: [
                          Shadow(
                            blurRadius: 10.0,
                            color: Colors.black.withOpacity(0.7),
                            offset: Offset(2.0, 2.0),
                          ),
                        ],
                      ),
                      textAlign: TextAlign.center,  // Centrado horizontal
                    ),
                    const SizedBox(height: 20),

                    // Campos adicionales
                    _buildTextField(_nameController, 'Nombre', Icons.person),
                    const SizedBox(height: 16),
                    _buildTextField(_surnameController, 'Apellidos', Icons.person),
                    const SizedBox(height: 16),
                    _buildTextField(_phoneController, 'Teléfono', Icons.phone),
                    const SizedBox(height: 16),
                    _buildGenderDropdown(),  // Campo de género
                    const SizedBox(height: 16),
                    _buildTextField(_dobController, 'Fecha de Nacimiento', Icons.calendar_today),
                    const SizedBox(height: 20),

                    // Campo para el correo electrónico
                    _buildTextField(_emailController, 'Correo electrónico', Icons.email),
                    const SizedBox(height: 16),

                    // Campo para la contraseña
                    _buildPasswordField(_passwordController, 'Contraseña'),
                    const SizedBox(height: 16),

                    // Campo para confirmar la contraseña
                    _buildPasswordField(_confirmPasswordController, 'Confirmar Contraseña'),
                    const SizedBox(height: 20),

                    // Botón de registro
                    ElevatedButton(
                      onPressed: () async {
                        final email = _emailController.text;
                        final password = _passwordController.text;
                        final confirmPassword = _confirmPasswordController.text;

                        if (password != confirmPassword) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('Las contraseñas no coinciden')),
                          );
                          return;
                        }

                        try {
                          // Registro con FirebaseAuthService
                          final user = await FirebaseAuthService.register(
                            email,
                            password,
                            _nameController.text,
                            _surnameController.text,
                            _phoneController.text,
                            _selectedGender!,  // Se pasa el género seleccionado
                            _dobController.text,
                          );

                          if (user != null) {
                            // Después de registrarse en FirebaseAuth, almacenar los otros datos
                            await FirebaseAuthService.saveUserData(
                              user.uid,
                              _nameController.text,
                              _surnameController.text,
                              _phoneController.text,
                              _selectedGender!,
                              _dobController.text,
                            );
                            // Redirigir a la pantalla de login después del registro exitoso
                            Navigator.pushReplacementNamed(context, '/');
                          }
                        } catch (e) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(content: Text('Error: $e')),
                          );
                        }
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.brown.shade600, // Color madera
                        minimumSize: const Size(double.infinity, 50),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: const Text(
                        'Registrarse',
                        style: TextStyle(fontSize: 16, color: Colors.white), // Texto blanco
                      ),
                    ),
                    const SizedBox(height: 20),

                    // Enlace para ir a la pantalla de login
                    TextButton(
                      onPressed: () {
                        Navigator.pushReplacementNamed(context, '/');
                      },
                      child: const Text(
                        '¿Ya tienes cuenta? Inicia sesión aquí.',
                        style: TextStyle(color: Colors.black),  // Color negro
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTextField(TextEditingController controller, String label, IconData icon) {
    return TextField(
      controller: controller,
      decoration: InputDecoration(
        labelText: label,
        labelStyle: TextStyle(color: Colors.green.shade900),
        prefixIcon: Icon(icon, color: Colors.green.shade900),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12.0),
          borderSide: BorderSide(color: Colors.green.shade900, width: 2),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12.0),
          borderSide: BorderSide(color: Colors.green.shade700, width: 2),
        ),
      ),
    );
  }

  Widget _buildPasswordField(TextEditingController controller, String label) {
    return TextField(
      controller: controller,
      obscureText: true,
      decoration: InputDecoration(
        labelText: label,
        labelStyle: TextStyle(color: Colors.green.shade900),
        prefixIcon: Icon(Icons.lock, color: Colors.green.shade900),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12.0),
          borderSide: BorderSide(color: Colors.green.shade900, width: 2),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12.0),
          borderSide: BorderSide(color: Colors.green.shade700, width: 2),
        ),
      ),
    );
  }

  Widget _buildGenderDropdown() {
    return DropdownButtonFormField<String>(
      value: _selectedGender,
      items: [
        // Opción para elegir el género
        DropdownMenuItem(value: 'Elegir Género', child: Text('Elegir Género')),
        DropdownMenuItem(value: 'Masculino', child: Text('Masculino')),
        DropdownMenuItem(value: 'Femenino', child: Text('Femenino')),
        DropdownMenuItem(value: 'Otro Género', child: Text('Otro Género')),
      ],
      onChanged: (String? newValue) {
        setState(() {
          _selectedGender = newValue;
        });
      },
      decoration: InputDecoration(
        labelText: 'Género',
        labelStyle: TextStyle(color: Colors.green.shade900),
        prefixIcon: Icon(Icons.transgender, color: Colors.green.shade900),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12.0),
          borderSide: BorderSide(color: Colors.green.shade900, width: 2),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12.0),
          borderSide: BorderSide(color: Colors.green.shade700, width: 2),
        ),
      ),
    );
  }
}

class WavePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.green.shade500
      ..style = PaintingStyle.fill;

    final path = Path();
    path.lineTo(0, size.height - 150); // Mover la ola más abajo
    path.quadraticBezierTo(size.width * 0.25, size.height - 220, size.width * 0.5, size.height - 150);
    path.quadraticBezierTo(size.width * 0.75, size.height - 80, size.width, size.height - 150);
    path.lineTo(size.width, size.height);
    path.lineTo(0, size.height);
    path.close();

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => false;
}
