import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:firebase_core/firebase_core.dart';

class PantallaCamara extends StatefulWidget {
  const PantallaCamara({Key? key}) : super(key: key);

  @override
  _PantallaCamaraState createState() => _PantallaCamaraState();
}

class _PantallaCamaraState extends State<PantallaCamara> {
  final ImagePicker _picker = ImagePicker();
  File? _image;
  String? _selectedCategory; // Almacena la categoría seleccionada

  // Lista de categorías de residuos
  List<String> categorias = ['Plástico', 'Papel', 'Vidrio', 'Orgánico'];

  @override
  void initState() {
    super.initState();
    Firebase.initializeApp(); // Inicializa Firebase al iniciar la pantalla
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.green[700],
        title: const Text('Clasificar Residuos', style: TextStyle(fontSize: 24)),
        centerTitle: true,
      ),
      body: Container(
        color: Colors.white, // Fondo blanco
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            // Mostrar la imagen capturada con tamaño reducido
            _image != null
                ? Container(
              height: 200,
              width: double.infinity,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(15),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.3),
                    spreadRadius: 5,
                    blurRadius: 7,
                    offset: Offset(0, 3),
                  ),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(15),
                child: Image.file(
                  _image!,
                  fit: BoxFit.cover,
                ),
              ),
            )
                : const Padding(
              padding: EdgeInsets.all(16.0),
              child: Text(
                'No se ha capturado ninguna imagen.',
                style: TextStyle(fontSize: 18, fontStyle: FontStyle.italic),
              ),
            ),
            const SizedBox(height: 20),

            // Botón para capturar una foto con un icono
            ElevatedButton.icon(
              onPressed: _takePicture,
              icon: Icon(Icons.camera_alt, size: 30, color: Colors.white),
              label: const Text('Tomar Foto', style: TextStyle(fontSize: 18)),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green[600],
                padding: EdgeInsets.symmetric(vertical: 15, horizontal: 20),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
            const SizedBox(height: 20),

            // Botón para elegir una imagen desde la galería
            ElevatedButton.icon(
              onPressed: _pickImageFromGallery,
              icon: Icon(Icons.photo_library, size: 30, color: Colors.white),
              label: const Text('Elegir de la Galería', style: TextStyle(fontSize: 18)),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue[600],
                padding: EdgeInsets.symmetric(vertical: 15, horizontal: 20),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
            const SizedBox(height: 20),

            // Selección de categoría de residuos con diseño más bonito
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 15),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: Colors.grey),
              ),
              child: DropdownButton<String>(
                value: _selectedCategory,
                hint: const Text('Selecciona una categoría', style: TextStyle(fontSize: 18)),
                onChanged: (String? newValue) {
                  setState(() {
                    _selectedCategory = newValue;
                  });
                },
                items: categorias.map<DropdownMenuItem<String>>((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value, style: TextStyle(fontSize: 18)),
                  );
                }).toList(),
                isExpanded: true,
                style: TextStyle(color: Colors.green[800]),
                underline: Container(),
              ),
            ),
            const SizedBox(height: 20),

            // Botón para guardar la imagen en la categoría seleccionada
            ElevatedButton.icon(
              onPressed: _image == null || _selectedCategory == null
                  ? null
                  : _saveImage,
              icon: Icon(Icons.save_alt, size: 30, color: Colors.white),
              label: const Text('Guardar Imagen', style: TextStyle(fontSize: 18)),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green[700],
                padding: EdgeInsets.symmetric(vertical: 15, horizontal: 20),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Función para tomar la foto con la cámara
  Future<void> _takePicture() async {
    final XFile? image = await _picker.pickImage(source: ImageSource.camera);
    if (image != null) {
      setState(() {
        _image = File(image.path);
      });
    }
  }

  // Función para seleccionar una imagen de la galería
  Future<void> _pickImageFromGallery() async {
    final XFile? image = await _picker.pickImage(source: ImageSource.gallery);
    if (image != null) {
      setState(() {
        _image = File(image.path);
      });
    }
  }

  // Función para subir la imagen a Firebase Storage
  Future<void> _saveImage() async {
    if (_image == null || _selectedCategory == null) return;

    try {
      // Subir la imagen a Firebase Storage en la categoría seleccionada
      final storageRef = FirebaseStorage.instance.ref();
      final categoryRef = storageRef.child('residuos/$_selectedCategory/${DateTime.now().millisecondsSinceEpoch}.jpg');

      // Subir el archivo
      await categoryRef.putFile(_image!);

      // Obtener la URL de la imagen almacenada
      final downloadURL = await categoryRef.getDownloadURL();

      // Aquí puedes guardar el URL en tu base de datos o realizar otras operaciones si es necesario
      setState(() {
        _selectedCategory = downloadURL; // Guardar la URL de Firebase
      });

      // Mostrar mensaje de éxito
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Imagen guardada con éxito en la Base de Datos')),
      );

      // Navegar de vuelta a la pantalla de inicio
      Navigator.pushReplacementNamed(context, '/inicio'); // Ruta correcta a la pantalla de inicio

    } catch (e) {
      // Mostrar mensaje de error
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Error al guardar la imagen en Firebase')),
      );
    }
  }
}
