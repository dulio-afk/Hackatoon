import 'package:flutter/material.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:firebase_auth/firebase_auth.dart';

class PantallaFotos extends StatefulWidget {
  const PantallaFotos({Key? key}) : super(key: key);

  @override
  _PantallaFotosState createState() => _PantallaFotosState();
}

class _PantallaFotosState extends State<PantallaFotos> {
  final FirebaseStorage _firebaseStorage = FirebaseStorage.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  // Lista de categorías de residuos
  final List<String> _categorias = ['Plásticos', 'Vidrio', 'Metales', 'Orgánico'];

  // Almacenar las fotos cargadas
  List<String> _fotos = [];

  // Cargar fotos por categoría
  Future<void> _cargarFotos(String categoria) async {
    setState(() {
      _fotos.clear(); // Limpiar las fotos antes de cargar las nuevas
    });

    // Verificar si el usuario está autenticado
    User? user = _auth.currentUser;
    if (user == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Debes iniciar sesión para ver las fotos.')),
      );
      return;
    }

    try {
      final ref = _firebaseStorage.ref().child('residuos/$categoria'); // Ruta correcta de Firebase
      final listResult = await ref.listAll();
      for (var item in listResult.items) {
        String url = await item.getDownloadURL(); // Obtener URL de cada imagen
        setState(() {
          _fotos.add(url); // Agregar la URL de cada foto a la lista
        });
      }
    } catch (e) {
      print('Error cargando fotos: $e');
      // Mostrar error si no se pueden cargar fotos
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Error al cargar las fotos.')),
      );
    }
  }

  // Mostrar el grid de fotos
  Widget _mostrarFotos() {
    if (_fotos.isEmpty) {
      return const Center(child: Text('No hay fotos para mostrar.'));
    } else {
      return GridView.builder(
        itemCount: _fotos.length,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          crossAxisSpacing: 8.0,
          mainAxisSpacing: 8.0,
        ),
        itemBuilder: (context, index) {
          return Image.network(_fotos[index], fit: BoxFit.cover); // Mostrar cada foto
        },
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.purple.shade600,
        title: const Text('Fotos Clasificadas'),
      ),
      body: Column(
        children: [
          // Botón para seleccionar la categoría de residuos
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: ElevatedButton(
              onPressed: () {
                // Mostrar un diálogo de selección de categoría
                showDialog<String>(  // Diálogo para elegir categoría
                  context: context,
                  builder: (BuildContext context) {
                    return AlertDialog(
                      title: const Text('Selecciona un tipo de residuo'),
                      content: SingleChildScrollView(
                        child: ListBody(
                          children: _categorias.map((categoria) {
                            return ListTile(
                              title: Text(categoria),
                              onTap: () {
                                Navigator.pop(context, categoria); // Cerrar el diálogo y seleccionar la categoría
                              },
                            );
                          }).toList(),
                        ),
                      ),
                    );
                  },
                ).then((categoriaSeleccionada) {
                  if (categoriaSeleccionada != null) {
                    _cargarFotos(categoriaSeleccionada); // Cargar fotos de la categoría seleccionada
                  }
                });
              },
              child: const Text('Seleccionar tipo de residuo'),
            ),
          ),

          // Mostrar las fotos del tipo de residuo seleccionado
          Expanded(
            child: _mostrarFotos(),
          ),
        ],
      ),
    );
  }
}
