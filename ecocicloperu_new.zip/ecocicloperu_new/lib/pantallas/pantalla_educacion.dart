import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart'; // Paquete para abrir enlaces externos

class PantallaEducacion extends StatelessWidget {
  const PantallaEducacion({Key? key}) : super(key: key);

  // Función para abrir enlaces en el navegador
  Future<void> _launchURL(String url) async {
    if (await canLaunchUrl(Uri.parse(url))) {
      await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    } else {
      throw 'No se puede abrir $url';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Educación Ambiental'),
        backgroundColor: Colors.green.shade700, // Color de fondo verde
      ),
      body: Container(
        color: Colors.white, // Fondo blanco
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Título introductorio
              Row(
                children: [
                  const Icon(Icons.eco, color: Colors.green, size: 35),
                  const SizedBox(width: 8),
                  const Text(
                    'Consejos para Cuidar el Medio Ambiente',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Colors.green,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),

              // Lista de consejos mejorada con iconos
              _buildTipCard(
                context,
                Icons.recycling,
                'Recicla tus Residuos',
                'Asegúrate de separar tus residuos reciclables como plástico, papel y vidrio.',
              ),
              _buildTipCard(
                context,
                Icons.no_drinks,
                'Reduce el Uso de Plástico',
                'Opta por productos reutilizables en lugar de plásticos de un solo uso.',
              ),
              _buildTipCard(
                context,
                Icons.water_drop,
                'Ahorra Agua',
                'Repara fugas y cierra el grifo mientras lavas tus manos o dientes.',
              ),
              _buildTipCard(
                context,
                Icons.wb_sunny,
                'Usa Energía Renovable',
                'Considera instalar paneles solares o usar energía eólica.',
              ),
              _buildTipCard(
                context,
                Icons.directions_bike,
                'Usa Transporte Sostenible',
                'Camina, usa bicicleta o transporte público para reducir emisiones.',
              ),
              _buildTipCard(
                context,
                Icons.shopping_cart,
                'Compra Productos Locales',
                'Apoya el comercio local para reducir el impacto ambiental del transporte.',
              ),
              _buildTipCard(
                context,
                Icons.nature,
                'Planta un Árbol',
                'Ayuda a purificar el aire y proporciona un hogar para la fauna.',
              ),
              const SizedBox(height: 20),

              // Sección de enlaces a recursos externos
              Row(
                children: [
                  const Icon(Icons.school, color: Colors.blue, size: 28),
                  const SizedBox(width: 8),
                  const Text(
                    'Recursos para Aprender Más:',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),

              // Enlaces a páginas educativas con iconos
              _buildResourceLink('https://www.conservation.org/peru', 'Conservación Internacional', Icons.public),
              _buildResourceLink('https://www.wwf.org', 'WWF - World Wildlife Fund', Icons.eco),
              _buildResourceLink('https://www.greenpeace.org', 'Greenpeace', Icons.nature_people),
              _buildResourceLink('https://www.earthday.org', 'Earth Day Organization', Icons.public),
              _buildResourceLink('https://www.unep.org', 'Programa de las Naciones Unidas para el Medio Ambiente', Icons.account_balance),
              _buildResourceLink('https://www.recycling-guide.org.uk', 'Guía de Reciclaje', Icons.recycling),
            ],
          ),
        ),
      ),
    );
  }

  // Método para construir las tarjetas de consejos
  Widget _buildTipCard(BuildContext context, IconData icon, String title, String description) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8.0),
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: ListTile(
        leading: Icon(icon, color: Colors.green, size: 32),
        title: Text(
          title,
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        subtitle: Text(description),
      ),
    );
  }

  // Método para crear enlaces a recursos externos con iconos
  Widget _buildResourceLink(String url, String label, IconData icon) {
    return InkWell(
      onTap: () => _launchURL(url),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 8.0),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: Colors.blue, size: 24),
            const SizedBox(width: 8),
            Flexible(
              child: Text(
                label,
                style: const TextStyle(
                  fontSize: 16,
                  color: Colors.blue,
                  decoration: TextDecoration.underline,
                ),
                overflow: TextOverflow.ellipsis, // Corta el texto si es muy largo
                maxLines: 1, // Muestra solo una línea
                softWrap: false, // Evita saltos de línea
              ),
            ),
          ],
        ),
      ),
    );
  }
}
