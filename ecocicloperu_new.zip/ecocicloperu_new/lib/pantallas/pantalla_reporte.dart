import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import 'package:permission_handler/permission_handler.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class PantallaReporte extends StatefulWidget {
  const PantallaReporte({Key? key}) : super(key: key);

  @override
  _PantallaReporteState createState() => _PantallaReporteState();
}

class _PantallaReporteState extends State<PantallaReporte> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _descripcionController = TextEditingController();
  String? _categoriaSeleccionada;
  late GoogleMapController mapController;

  final List<String> categorias = ['Basura', 'Acumulación', 'Otro'];
  LatLng _ubicacionActual = LatLng(0.0, 0.0);
  LatLng? _ubicacionDestino;
  Set<Polyline> _polylines = {}; // Para almacenar y mostrar rutas en el mapa.

  @override
  void initState() {
    super.initState();
    _getUbicacionActual();
  }

  // Obtener la ubicación actual del usuario
  Future<void> _getUbicacionActual() async {
    var status = await Permission.location.request();
    if (status.isGranted) {
      try {
        Position position = await Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.high,
        );
        setState(() {
          _ubicacionActual = LatLng(position.latitude, position.longitude);
        });
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error al obtener la ubicación: $e')),
        );
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Permiso de ubicación no concedido')),
      );
    }
  }

  // Obtener la ruta desde Directions API
  Future<List<LatLng>> obtenerRuta(LatLng origen, LatLng destino) async {
    const String apiKey = "TU_API_KEY_DE_GOOGLE_MAPS";
    final String url =
        "https://maps.googleapis.com/maps/api/directions/json?origin=${origen.latitude},${origen.longitude}&destination=${destino.latitude},${destino.longitude}&key=$apiKey";

    final response = await http.get(Uri.parse(url));
    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      final steps = data["routes"][0]["legs"][0]["steps"] as List;
      return steps.map((step) {
        final startLocation = step["start_location"];
        return LatLng(startLocation["lat"], startLocation["lng"]);
      }).toList();
    } else {
      throw Exception("Error al obtener la ruta: ${response.statusCode}");
    }
  }

  // Mostrar la ruta en el mapa
  void mostrarRuta(LatLng origen, LatLng destino) async {
    final puntos = await obtenerRuta(origen, destino);
    setState(() {
      _polylines.clear(); // Limpiar rutas previas
      _polylines.add(
        Polyline(
          polylineId: PolylineId("ruta"),
          points: puntos,
          color: Colors.blue,
          width: 5,
        ),
      );
    });
  }

  // Calcular distancia con Distance Matrix API
  Future<String> calcularDistancia(LatLng origen, LatLng destino) async {
    const String apiKey = "TU_API_KEY_DE_GOOGLE_MAPS";
    final String url =
        "https://maps.googleapis.com/maps/api/distancematrix/json?origins=${origen.latitude},${origen.longitude}&destinations=${destino.latitude},${destino.longitude}&key=$apiKey";

    final response = await http.get(Uri.parse(url));
    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      return data["rows"][0]["elements"][0]["distance"]["text"];
    } else {
      throw Exception("Error al calcular la distancia: ${response.statusCode}");
    }
  }

  // Guardar el reporte en Firebase
  Future<void> guardarReporte() async {
    try {
      final reportesRef = FirebaseFirestore.instance.collection('reportes');
      await reportesRef.add({
        'descripcion': _descripcionController.text,
        'ubicacion': GeoPoint(_ubicacionActual.latitude, _ubicacionActual.longitude),
        'categoria': _categoriaSeleccionada,
        'fecha': FieldValue.serverTimestamp(),
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Reporte enviado con éxito')),
      );

      _descripcionController.clear();
      setState(() {
        _categoriaSeleccionada = null;
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Error al enviar el reporte')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Reportar Acumulación'),
        backgroundColor: Colors.blue,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              DropdownButtonFormField<String>(
                value: _categoriaSeleccionada,
                hint: const Text('Selecciona una categoría'),
                onChanged: (String? newValue) {
                  setState(() {
                    _categoriaSeleccionada = newValue;
                  });
                },
                validator: (value) {
                  if (value == null) {
                    return 'Por favor selecciona una categoría';
                  }
                  return null;
                },
                items: categorias
                    .map((categoria) => DropdownMenuItem<String>(
                  value: categoria,
                  child: Row(
                    children: [
                      Icon(
                        categoria == 'Basura'
                            ? Icons.delete
                            : categoria == 'Acumulación'
                            ? Icons.warning
                            : Icons.help,
                        color: Colors.blue,
                      ),
                      const SizedBox(width: 8),
                      Text(categoria),
                    ],
                  ),
                ))
                    .toList(),
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _descripcionController,
                decoration: const InputDecoration(
                  labelText: 'Descripción del reporte',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.text_fields),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Por favor ingresa una descripción';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),
              Container(
                height: 300,
                child: GoogleMap(
                  initialCameraPosition: CameraPosition(
                    target: _ubicacionActual,
                    zoom: 14.0,
                  ),
                  onMapCreated: (controller) {
                    mapController = controller;
                  },
                  markers: {
                    Marker(
                      markerId: MarkerId("origen"),
                      position: _ubicacionActual,
                      infoWindow: InfoWindow(title: "Ubicación Actual"),
                    ),
                    if (_ubicacionDestino != null)
                      Marker(
                        markerId: MarkerId("destino"),
                        position: _ubicacionDestino!,
                        infoWindow: InfoWindow(title: "Destino"),
                      ),
                  },
                  polylines: _polylines,
                  onTap: (LatLng location) {
                    setState(() {
                      _ubicacionDestino = location;
                      mostrarRuta(_ubicacionActual, location);
                    });
                  },
                ),
              ),
              const SizedBox(height: 16),
              if (_ubicacionDestino != null)
                FutureBuilder<String>(
                  future: calcularDistancia(_ubicacionActual, _ubicacionDestino!),
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return const CircularProgressIndicator();
                    } else if (snapshot.hasError) {
                      return Text("Error: ${snapshot.error}");
                    } else {
                      return Text("Distancia al destino: ${snapshot.data}");
                    }
                  },
                ),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: () {
                  if (_formKey.currentState?.validate() ?? false) {
                    guardarReporte();
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Por favor completa el formulario')),
                    );
                  }
                },
                child: const Text('Enviar Reporte'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
