class Usuario {
  final String id;
  final String email;

  Usuario({required this.id, required this.email});

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'email': email,
    };
  }

  factory Usuario.fromMap(Map<String, dynamic> map) {
    return Usuario(
      id: map['id'] ?? '',
      email: map['email'] ?? '',
    );
  }
}
