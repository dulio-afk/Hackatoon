class PigeonUserDetails {
  final String? userId;
  final String? email;

  PigeonUserDetails({
    required this.userId,
    required this.email,
  });
}
